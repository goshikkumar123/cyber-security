# Cyber Security Attack Analysis Dashboard

Python portfolio starter for exploring incident frequency, severity, hourly patterns and data exfiltration.

## Run
```bash
python -m pip install -r requirements.txt
python analysis.py
```
If `data/cyber_attacks.csv` is absent, the script creates a clearly labelled **synthetic demonstration dataset**. Replace it with an authorized real dataset using the same columns: `timestamp, attack_type, severity, source_country, target_asset, data_exfiltrated_mb, status`.

## Outputs
- `outputs/hourly_attack_trend.png`
- `outputs/severity_heatmap.png`
- `outputs/data_exfiltration.png`
- `outputs/attack_summary.csv`

**Important:** This is a recreated starter implementation, not recovered original project code or evidence of analysis on real security incidents.
