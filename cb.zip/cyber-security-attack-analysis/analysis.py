"""
Cyber Security Attack Analysis Dashboard
Reproducible portfolio starter using Python, pandas, matplotlib and seaborn.
The included generator creates DEMONSTRATION data, not real incident records.
Run: python analysis.py
"""
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

OUT = Path("outputs")
OUT.mkdir(exist_ok=True)
DATA = Path("data/cyber_attacks.csv")

def make_demo_data(n=2500, seed=42):
    rng = np.random.default_rng(seed)
    attack_types = ["Phishing", "DDoS", "Malware", "SQL Injection", "Brute Force", "Data Exfiltration"]
    severity = rng.choice(["Low", "Medium", "High", "Critical"], n, p=[.22, .38, .29, .11])
    attack = rng.choice(attack_types, n, p=[.27, .18, .18, .12, .15, .10])
    hour = rng.choice(np.arange(24), n, p=np.array(
        [.015,.012,.010,.009,.008,.010,.018,.035,.060,.065,.060,.055,
         .050,.048,.050,.055,.060,.065,.070,.065,.055,.040,.025,.020]))
    severity_rate = pd.Series(severity).map({"Low": .1, "Medium": .3, "High": .65, "Critical": .9}).to_numpy()
    exfil = np.where(attack == "Data Exfiltration",
                     rng.uniform(20, 900, n),
                     rng.uniform(0, 100, n) * severity_rate)
    df = pd.DataFrame({
        "timestamp": pd.Timestamp("2026-03-01") + pd.to_timedelta(rng.integers(0, 31*24*60, n), unit="m"),
        "attack_type": attack,
        "severity": severity,
        "source_country": rng.choice(["India","USA","Germany","China","Brazil","UK"], n),
        "target_asset": rng.choice(["Web Server","Database","Endpoint","Cloud Storage","Email Gateway"], n),
        "data_exfiltrated_mb": exfil.round(2),
        "status": rng.choice(["Blocked","Investigated","Successful"], n, p=[.62,.25,.13])
    })
    return df.sort_values("timestamp")

def main():
    if DATA.exists():
        df = pd.read_csv(DATA, parse_dates=["timestamp"])
    else:
        df = make_demo_data()
        DATA.parent.mkdir(exist_ok=True)
        df.to_csv(DATA, index=False)
        print(f"Created demo dataset at {DATA} (synthetic data).")
    df["hour"] = df["timestamp"].dt.hour
    print("\\nRows:", len(df))
    print("\\nSeverity counts:\\n", df["severity"].value_counts())
    print("\\nAttack types:\\n", df["attack_type"].value_counts())

    sns.set_theme(style="whitegrid")
    fig, ax = plt.subplots(figsize=(10, 5))
    df.groupby("hour").size().reindex(range(24), fill_value=0).plot(kind="line", marker="o", ax=ax)
    ax.set(title="Cyber Attacks by Hour", xlabel="Hour of day", ylabel="Number of attacks")
    fig.tight_layout(); fig.savefig(OUT/"hourly_attack_trend.png", dpi=160); plt.close(fig)

    heat = pd.crosstab(df["attack_type"], df["severity"]).reindex(
        columns=["Low","Medium","High","Critical"], fill_value=0)
    fig, ax = plt.subplots(figsize=(10, 5))
    sns.heatmap(heat, annot=True, fmt="d", cmap="YlOrRd", ax=ax)
    ax.set(title="Attack Type vs Severity", xlabel="Severity", ylabel="Attack type")
    fig.tight_layout(); fig.savefig(OUT/"severity_heatmap.png", dpi=160); plt.close(fig)

    fig, ax = plt.subplots(figsize=(10, 5))
    df.groupby("attack_type")["data_exfiltrated_mb"].sum().sort_values().plot(kind="barh", ax=ax)
    ax.set(title="Data Exfiltration by Attack Type", xlabel="Data exfiltrated (MB)", ylabel="")
    fig.tight_layout(); fig.savefig(OUT/"data_exfiltration.png", dpi=160); plt.close(fig)

    summary = df.groupby("attack_type").agg(
        incidents=("attack_type","size"),
        high_or_critical=("severity", lambda s: s.isin(["High","Critical"]).sum()),
        exfiltrated_mb=("data_exfiltrated_mb","sum")
    ).sort_values("incidents", ascending=False)
    summary.to_csv(OUT/"attack_summary.csv")
    print("\\nSaved charts and summary in outputs/")

if __name__ == "__main__":
    main()
